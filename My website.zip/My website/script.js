document.addEventListener('DOMContentLoaded', function() {
    const button = document.createElement('button');
    button.textContent = 'Change Background Color';
    document.body.appendChild(button);

    button.addEventListener('click', function() {
        document.body.style.backgroundColor = '#ffcc00'; // changes background to yellow
    });
});
